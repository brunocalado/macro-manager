0.2.0
- tools macro fix
- macros in the world will run even if the player don't have permission to execute that macro
- keybind for players fixed 1-9

0.1.9
- small refactor

0.1.8
- transparent dialog background, but working

0.1.7
- quick fix 

0.1.6
- transparent dialog background fix

0.1.5
- transparent dialog background

0.1.4
- minor fixes
- improved dialog, add template for easier manipulation
- stringListToArray removes empty, prevent not working with extra ;;;
- error handling for compendium
- themes

0.1.3
- header
- tools: documentation link

0.1.2
- Tool: Get all macro names from compendium
- summary replaced by tools. It's inside tools
- sort names option
- fix bug: macros in compendium run now

0.1.1
- compendium with demo macros
- you can use macros inside compendium
- BREAKING: openCustomMacroManager use an object as arg. Read docs

0.1.0
- create custom macro, no need for settings

0.0.9
- option for enable keyboard shortcut for players
- localization

0.0.8
- fix text controls

0.0.7
- docs
- up to 9 managers
- summary: shift + 0
- gm only keybinds